from setuptools import setup

package_name = 'ultrasonic_sensor'

setup(
    name=package_name,
    version='0.0.0',
    packages=[package_name],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='your_name',
    maintainer_email='your_email@example.com',
    description='ROS2 Ultrasonic Sensor Node',
    license='License declaration',
    tests_require=['pytest'],
    entry_points={
        'console_scripts': [
            'ultrasonic_sensor_node = ultrasonic_sensor.ultrasonic_sensor_node:main',
        ],
    },
)
