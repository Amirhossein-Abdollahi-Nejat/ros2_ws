import rclpy
from rclpy.node import Node
import RPi.GPIO as GPIO
import time
from sensor_msgs.msg import Range

class UltrasonicSensorNode(Node):

    def __init__(self):
        super().__init__('ultrasonic_sensor_node')

        self.publisher_ = self.create_publisher(Range, 'ultrasonic_range', 10)
        self.timer = self.create_timer(0.1, self.timer_callback)

        self.TRIG = 23
        self.ECHO = 24

        GPIO.setmode(GPIO.BCM)
        GPIO.setup(self.TRIG, GPIO.OUT)
        GPIO.setup(self.ECHO, GPIO.IN)

    def timer_callback(self):
        GPIO.output(self.TRIG, False)
        time.sleep(0.000002)
        GPIO.output(self.TRIG, True)
        time.sleep(0.00001)
        GPIO.output(self.TRIG, False)

        while GPIO.input(self.ECHO) == 0:
            pulse_start = time.time()

        while GPIO.input(self.ECHO) == 1:
            pulse_end = time.time()

        pulse_duration = pulse_end - pulse_start
        distance = pulse_duration * 17150
        distance = round(distance, 2)

        if distance > 2 and distance < 400:
            msg = Range()
            msg.header.stamp = self.get_clock().now().to_msg()
            msg.radiation_type = Range.ULTRASOUND
            msg.field_of_view = 0.05
            msg.min_range = 0.02
            msg.max_range = 4.0
            msg.range = distance / 100  # Convert to meters

            self.publisher_.publish(msg)

    def destroy(self):
        GPIO.cleanup()

def main(args=None):
    rclpy.init(args=args)

    node = UltrasonicSensorNode()
    rclpy.spin(node)

    node.destroy()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
