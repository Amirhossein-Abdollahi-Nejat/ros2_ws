import rclpy
from rclpy.node import Node
from std_msgs.msg import Int32
import RPi.GPIO as GPIO
import time

class DopplerRadarNode(Node):
    def __init__(self):
        super().__init__('doppler_radar_node')

        # Define GPIO pin
        self.pbIn_pin = 27  # GPIO pin number on the Raspberry Pi

        # Initialize count and threshold
        self.count = 0
        self.threshold = 6

        # Set up GPIO
        try:
            GPIO.setmode(GPIO.BCM)
            GPIO.setup(self.pbIn_pin, GPIO.IN)
            GPIO.add_event_detect(self.pbIn_pin, GPIO.RISING, callback=self.state_change)
        except Exception as e:
            self.get_logger().error(f'Failed to set up GPIO: {e}')
            raise

        # Create a publisher to publish the count data
        self.publisher_ = self.create_publisher(Int32, 'doppler_radar_count', 10)

        # Create a timer to periodically publish the count
        self.timer = self.create_timer(0.1, self.publish_count)

    def state_change(self, channel):
        self.count += 1

    def publish_count(self):
        # Publish the count value
        count_copy = self.count
        self.count = 0
        msg = Int32()
        msg.data = count_copy
        self.publisher_.publish(msg)
        self.get_logger().info(f'Published count: {count_copy}')

    def __del__(self):
        try:
            GPIO.cleanup()
        except Exception as e:
            self.get_logger().error(f'Failed to clean up GPIO: {e}')

def main(args=None):
    rclpy.init(args=args)

    try:
        doppler_radar_node = DopplerRadarNode()
        rclpy.spin(doppler_radar_node)
    except KeyboardInterrupt:
        pass
    finally:
        doppler_radar_node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()
