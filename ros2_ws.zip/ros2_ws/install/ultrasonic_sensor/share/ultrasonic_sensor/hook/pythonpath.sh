# generated from colcon_core/shell/template/hook_prepend_value.sh.em

_colcon_prepend_unique_value PYTHONPATH "$COLCON_CURRENT_PREFIX/lib/python3.10/site-packages"
